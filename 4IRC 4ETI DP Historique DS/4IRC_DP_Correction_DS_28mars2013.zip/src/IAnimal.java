
/**
 * 
 * @author Fran�oise PERRIN
 */

public interface IAnimal {
	public String getName ();
	public void setName(String name);
}
