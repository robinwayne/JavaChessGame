/**
 * 
 * @author Fran�oise PERRIN
 */

import java.util.Observable;
import java.util.Observer;


// D�core les ITreeSleeper afin de les rendre observables

public class TreeSleeperDecorateObservable implements ITreeSleeper, IObservable {
		
	protected ITreeSleeper treeSleeper ; // le TreeSleeper d�cor�
	
	// DP Strategy : on d�l�gue � l'objet observable la gestion des observateurs
	Observable observable;
	
	TreeSleeperDecorateObservable() {
		super();
	}	
	TreeSleeperDecorateObservable(ITreeSleeper treeSleeper, Observable observable) {
		super();
		this.treeSleeper = (ITreeSleeper) treeSleeper;
		this.observable =  observable;	
		observable.notifyObservers(treeSleeper);
	}
	
	public void setObservable (Observable observable) {
		this.observable = observable;
		observable.notifyObservers(treeSleeper);
	}
	
	public void addObserver(Observer observateur) {	
		observable.addObserver(observateur);		
	}
 
	public void notifyObservers(Object treeSleeper) {	
		observable.notifyObservers(treeSleeper);
	}

	public void setSleepLib() {
		treeSleeper.setSleepLib()	;
		notifyObservers(treeSleeper);
	}

	public void setAwakeLib() {
		treeSleeper.setAwakeLib();	
		notifyObservers(treeSleeper);
	}

	@Override
	public void awakening() {
		treeSleeper.awakening();
		notifyObservers(treeSleeper);
	}

	@Override
	public void sleepInTree() {
		treeSleeper.sleepInTree();
		notifyObservers(treeSleeper);
	}
	
	@Override
	public String getSleepLong() {		
		return treeSleeper.getSleepLong();
	}

	@Override
	public String getSleepShort() {
		return treeSleeper.getSleepShort();
	}

	@Override
	public boolean getSleepState() {
		return treeSleeper.getSleepState();
	}

	@Override
	public String getName() {
		return treeSleeper.getName();
	}

	@Override
	public void setName(String name) {
		treeSleeper.setName(name);
	}
	
	public String toString() {
		return treeSleeper.toString();
	}
}
