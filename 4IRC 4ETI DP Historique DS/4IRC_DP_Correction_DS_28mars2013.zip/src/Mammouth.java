/**
 * 
 * @author Fran�oise PERRIN
 */

public class Mammouth extends AbstractAnimal implements IElephantidae {
	
	Mammouth(String name){
		super(name);
	}
	// M�thodes sp�cifiques aux IElephantidae
}
