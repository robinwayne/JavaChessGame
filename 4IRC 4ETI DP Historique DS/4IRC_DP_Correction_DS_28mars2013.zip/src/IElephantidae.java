
/**
 * 
 * @author Fran�oise PERRIN
 */

public interface IElephantidae extends IAnimal {

}
