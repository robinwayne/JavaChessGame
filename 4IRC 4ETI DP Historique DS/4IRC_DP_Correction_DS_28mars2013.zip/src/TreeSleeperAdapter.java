/**
 * 
 * @author Fran�oise PERRIN
 */

// adaptateur d'animaux en ITreeSleeper

public abstract class TreeSleeperAdapter extends AbstractTreeSleeper  {
	IAnimal animal;
	
	public String toString() {
		return animal.toString();
	}

	public TreeSleeperAdapter(IAnimal animal){
		super(animal);
		this.animal=animal;
	}
}
