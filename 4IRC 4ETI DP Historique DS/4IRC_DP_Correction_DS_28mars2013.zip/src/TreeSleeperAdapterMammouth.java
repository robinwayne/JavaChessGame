
/**
 * 
 * @author Fran�oise PERRIN
 */

// adaptateur d'animaux en ITreeSleeper
// ex : Adaptateur de mammouth
public class TreeSleeperAdapterMammouth extends TreeSleeperAdapter  {
	
	public String toString() {
		return super.toString() + ", voulant dormir comme un opposum,";
	}

	public TreeSleeperAdapterMammouth(IAnimal mammouth){
		super(mammouth);		
	}
 
	public void setSleepLib() {
		setSleepLong(" vient de s'endormir accroch� par la queue");
		setSleepShort(" endormi");		
	}

	public void setAwakeLib() {
		setSleepLong(" vient de se r�veiller et descend de l'arbre");
		setSleepShort(" �veill�");	
	}

}
